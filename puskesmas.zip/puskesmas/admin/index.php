<?php
  session_start();
  require '../config.php';
  if (!isset($_SESSION['admin']) || $_SESSION['admin'] == "") {
    header("location: ../index.php");
  }
  $sql = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM janji"));
  $jml_janji = $sql['total'];
  $sql = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM pasien"));
  $jml_pasien = $sql['total'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Puskesmas Sidoarjo - Admin</title>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">

  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

  <!-- =======================================================
  * Template Name: OnePage - v4.3.0
  * Template URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <!-- <img src="../assets/img/logo.png" alt=""> -->
      <!-- Uncomment below if you prefer to use an image logo -->
      <a href="../index.php" class="logo"><img src="../assets/img/logo.png" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="../index.php">Beranda</a></li>
          <li><a class="nav-link scrollto" href="../ttgkm.php">Tentang Kami</a></li>
          <li><a class="nav-link scrollto" href="../artkl.php">Artikel Kesehatan</a></li>
          <li class="dropdown"><a href="#"><span>Layanan</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="../buatjanji.php">Buat Janji Dokter</a></li>
              <li><a href="../konsul_online.php">Konsultasi Dokter Online</a></li>
              <li><a href="../gawat.php">Gawat Darurat</a></li>
              <li><a href="../vaksin.php">Vaksin Covid-19</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="index.php#contact">Kontak</a></li>
          <?php if (isset($_SESSION['admin'])): ?>
            <li><a class="getstarted scrollto" href="../logout.php">Keluar</a></li>
          <?php else: ?>
            <li><a class="getstarted scrollto" href="../loginadmin.php">Masuk</a></li>
          <?php endif; ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->

  <section id="hero" class="d-flex align-items-center">
    <div class="container position-relative" data-aos="fade-up" data-aos-delay="100">
      <div class="row justify-content-center">
        <div class="col-xl-7 col-lg-9 text-center">
          <h1>Selamat Datang</h1>
          <h2>di Website Puskesmas Sidoarjo</h2>
        </div>
        <center>
          <div class="chart">
            <canvas id="chart_janji" style="min-height: auto; height: 400px; max-height: auto; max-width: auto;"></canvas>
          </div>
        </center>
        <div class="col-xl-7 col-lg-9 text-center mt-5">
          <h2>Data Pasien</h2>
        </div>
        <table id="obat" class="table table-bordered table-striped">
            <thead>
                <tr>
                  <th>Email</th>
                  <th>No. Kartu Peserta</th>
                  <th>Nama</th>
                  <th>Tanggal Lahir</th>
                  <th>Alamat</th>
                  <th>RT</th>
                  <th>RW</th>
                  <th>No. Wa</th>
                  <th>No. KK</th>
                  <th>NIK</th>
                </tr>
            </thead>
            <tbody>
              <?php
                $data = mysqli_query($conn,"SELECT * FROM pasien");
                foreach ($data as $d) {
              ?>
              <tr>
                <td><?= $d['email'] ?></td>
                <td><?= $d['no_karpas'] ?></td>
                <td><?= $d['nama'] ?></td>
                <td><?= $d['tgl_lahir'] ?></td>
                <td><?= $d['alamat'] ?></td>
                <td><?= $d['rt'] ?></td>
                <td><?= $d['rw'] ?></td>
                <td><?= $d['no_wa'] ?></td>
                <td><?= $d['no_kk'] ?></td>
                <td><?= $d['nik'] ?></td>
              </tr>
              <?php
                }
              ?>
            </tbody>
        </table>
      </div>
    </div>
  </section><!-- End Hero -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Puskesmas Sidoarjo</h3>
            <p>
              Jl. Dr. Soetomo No.14, Magersari<br>
              Kec. Sidoarjo, Kab. Sidoarjo 61212<br>
              Jawa Timur, Indonesia <br><br>
              <strong>Telepon:</strong> (031) 8921956; 08113322225<br>
              <strong>Email:</strong> puskesmassidoarjo@sidoarjokab.go.id<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Link Tujuan</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Beranda</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Tentang Kami</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Artikel Kesehatan</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Layanan</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Kontak</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Layanan Kami</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Buat Janji Dokter</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Konsultasi Dokter Online</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Gawat Darurat</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Daftar Vaksin Covid-19</a></li>
            </ul>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; 2021 <strong><span>Puskesmas Sidoarjo</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          Designed by Kevin Khanza Pangestu</a>
        </div>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
  <script src="../assets/vendor/purecounter/purecounter.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.3.2/chart.js" integrity="sha512-CAv0l04Voko2LIdaPmkvGjH3jLsH+pmTXKFoyh5TIimAME93KjejeP9j7wSeSRXqXForv73KUZGJMn8/P98Ifg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

  <!-- DataTables  & Plugins -->
  <script src="plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
  <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
  <script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
  <script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
  <script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script src="plugins/jszip/jszip.min.js"></script>
  <script src="plugins/pdfmake/pdfmake.min.js"></script>
  <script src="plugins/pdfmake/vfs_fonts.js"></script>
  <script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
  <script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
  <script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
  <script>
  $(function () {
    var areaChartData = {
      labels  : ['Grafik Puskesmas'],
      datasets: [
        {
          label: "Pasien",
          data: "<?= $jml_pasien ?>",
          backgroundColor : ['yellow'],
        },
        {
          label: "Janji",
          data: "<?= $jml_janji ?>",
          backgroundColor : ['green'],
        }
      ]
    }
    var barChartCanvas = $('#chart_janji').get(0).getContext('2d')
    var barChartData = jQuery.extend(true, {}, areaChartData)
    var temp0 = areaChartData.datasets[0]
    barChartData.datasets[0] = temp0

    var barChartOptions = {
      responsive              : true,
      maintainAspectRatio     : false,
      datasetFill             : false
    }

    var barChart = new Chart(barChartCanvas, {
      type: 'bar',
      data: barChartData,
      options: barChartOptions
    })
    $("#obat").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "paging": true,
      "buttons": [
            {
                extend: 'excelHtml5',
                title: 'Data Obat'
            },
            {
                extend: 'pdfHtml5',
                title: 'Data Obat'
            }
        ]
    }).buttons().container().appendTo('#obat_wrapper .col-md-6:eq(0)');
  });
</script>

</body>

</html>
